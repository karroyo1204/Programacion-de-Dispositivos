package com.karroyo80069.pulperiaj

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
