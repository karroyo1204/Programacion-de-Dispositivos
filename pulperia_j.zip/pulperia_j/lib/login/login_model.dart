import '../auth/auth_util.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LoginModel extends FlutterFlowModel {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for txtuser widget.
  TextEditingController? txtuserController;
  String? Function(BuildContext, String?)? txtuserControllerValidator;
  // State field(s) for TextClave widget.
  TextEditingController? textClaveController;
  late bool textClaveVisibility;
  String? Function(BuildContext, String?)? textClaveControllerValidator;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    textClaveVisibility = false;
  }

  void dispose() {
    txtuserController?.dispose();
    textClaveController?.dispose();
  }

  /// Additional helper methods are added here.

}
