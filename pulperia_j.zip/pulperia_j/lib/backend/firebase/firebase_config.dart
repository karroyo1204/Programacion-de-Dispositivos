import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDaEqvFuVQC81Rlr4udI9Xh9yzt7-40LhI",
            authDomain: "pulperia-j80069.firebaseapp.com",
            projectId: "pulperia-j80069",
            storageBucket: "pulperia-j80069.appspot.com",
            messagingSenderId: "288331791220",
            appId: "1:288331791220:web:29d38459a706cd74898a21"));
  } else {
    await Firebase.initializeApp();
  }
}
