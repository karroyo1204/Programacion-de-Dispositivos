package com.mycompany.sushiapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
